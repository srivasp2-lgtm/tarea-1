// 1. Contar palabras
function contarPalabras(texto) {
    let palabras = 0;
    let dentro = false;

    for (let i = 0; i < texto.length; i++) {
        let c = texto[i];

        if (c !== " " && c !== "\n" && !dentro) {
            dentro = true;
            palabras++;
        }

        if (c === " " || c === "\n") {
            dentro = false;
        }
    }

    return palabras;
}

// 2. Signos de puntuación
function contarSignos(texto) {
    let signos = ".,;:!?¿¡\"";
    let cont = 0;

    for (let i = 0; i < texto.length; i++) {
        for (let j = 0; j < signos.length; j++) {
            if (texto[i] === signos[j]) cont++;
        }
    }

    return cont;
}

// 3. Vocales
function contarVocales(texto) {
    let vocales = "aeiouAEIOU";
    let cont = 0;

    for (let i = 0; i < texto.length; i++) {
        for (let j = 0; j < vocales.length; j++) {
            if (texto[i] === vocales[j]) cont++;
        }
    }
    return cont;
}

// 4. Consonantes
function contarConsonantes(texto) {
    let vocales = "aeiouAEIOU";
    let abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let cont = 0;

    for (let i = 0; i < texto.length; i++) {
        let c = texto[i];

        // es letra
        let esLetra = false;
        for (let j = 0; j < abc.length; j++) {
            if (c === abc[j]) esLetra = true;
        }

        if (!esLetra) continue;

        // verificar que NO sea vocal
        let esVocal = false;
        for (let k = 0; k < vocales.length; k++) {
            if (c === vocales[k]) esVocal = true;
        }

        if (!esVocal) cont++;
    }

    return cont;
}

// 5. Dígitos
function contarDigitos(texto) {
    let digitos = "0123456789";
    let cont = 0;

    for (let i = 0; i < texto.length; i++) {
        for (let j = 0; j < digitos.length; j++) {
            if (texto[i] === digitos[j]) cont++;
        }
    }
    return cont;
}

// 6. Palabras que empiezan en mayúscula
function palabrasMayuscula(texto) {
    let mayus = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let cont = 0;
    let iniciar = true;

    for (let i = 0; i < texto.length; i++) {
        if (texto[i] !== " " && texto[i] !== "\n") {
            if (iniciar) {
                for (let j = 0; j < mayus.length; j++) {
                    if (texto[i] === mayus[j]) cont++;
                }
                iniciar = false;
            }
        } else {
            iniciar = true;
        }
    }

    return cont;
}

// 7. Palabras que empiezan en minúscula
function palabrasMinuscula(texto) {
    let minus = "abcdefghijklmnopqrstuvwxyz";
    let cont = 0;
    let iniciar = true;

    for (let i = 0; i < texto.length; i++) {
        if (texto[i] !== " " && texto[i] !== "\n") {
            if (iniciar) {
                for (let j = 0; j < minus.length; j++) {
                    if (texto[i] === minus[j]) cont++;
                }
                iniciar = false;
            }
        } else {
            iniciar = true;
        }
    }

    return cont;
}

// 8. Contar párrafos
function contarParrafos(texto) {
    if (texto.length === 0) return 0;

    let cont = 1;
    for (let i = 0; i < texto.length; i++) {
        if (texto[i] === "\n") cont++;
    }
    return cont;
}

// 9. Invertir texto
function invertirTexto(texto) {
    let invertido = "";

    for (let i = texto.length - 1; i >= 0; i--) {
        invertido += texto[i];
    }

    return invertido;
}

// 10. Total de caracteres
function contarCaracteres(texto) {
    return texto.length;
}

// 11. Buscar palabra dentro del texto (sin split)
function buscarPalabra(texto, palabra) {
    let coincidencia = 0;

    for (let i = 0; i < texto.length; i++) {
        let igual = true;

        for (let j = 0; j < palabra.length; j++) {
            if (texto[i + j] !== palabra[j]) {
                igual = false;
                break;
            }
        }

        if (igual) coincidencia++;
    }

    return coincidencia > 0;
}

// 12. Contar carácter específico
function contarCaracter(texto, c) {
    let cont = 0;
    for (let i = 0; i < texto.length; i++) {
        if (texto[i] === c) cont++;
    }
    return cont;
}

// 13. Caracteres en posiciones pares
function caracteresPares(texto) {
    let cont = 0;
    for (let i = 0; i < texto.length; i += 2) cont++;
    return cont;
}

// 14. Caracteres en posiciones impares
function caracteresImpares(texto) {
    let cont = 0;
    for (let i = 1; i < texto.length; i += 2) cont++;
    return cont;
}

// 15. Añadir texto al inicio y al final
function agregarTexto(texto, extra) {
    return {
        inicio: extra + " " + texto,
        fin: texto + " " + extra
    };
}


// ==============================
// EJECUTAR TODO EN UN BOTÓN
// ==============================
function analizarTexto() {
    let texto = document.getElementById("texto").value;

    let palabraBuscar = "programar";   // palabra de ejemplo
    let caracterBuscar = "o";          // caracter ejemplo
    let extra = "Nuevo";               // texto adicional

    let res = "";

    res += "Palabras: " + contarPalabras(texto) + "\n";
    res += "Signos: " + contarSignos(texto) + "\n";
    res += "Vocales: " + contarVocales(texto) + "\n";
    res += "Consonantes: " + contarConsonantes(texto) + "\n";
    res += "Digitos: " + contarDigitos(texto) + "\n";
    res += "Palabras Mayúscula: " + palabrasMayuscula(texto) + "\n";
    res += "Palabras Minúscula: " + palabrasMinuscula(texto) + "\n";
    res += "Párrafos: " + contarParrafos(texto) + "\n";
    res += "Texto invertido: " + invertirTexto(texto) + "\n";
    res += "Total caracteres: " + contarCaracteres(texto) + "\n";
    res += "¿Existe '" + palabraBuscar + "'?: " + buscarPalabra(texto, palabraBuscar) + "\n";
    res += "Caracter '" + caracterBuscar + "' aparece: " + contarCaracter(texto, caracterBuscar) + "\n";
    res += "Caracteres pares: " + caracteresPares(texto) + "\n";
    res += "Caracteres impares: " + caracteresImpares(texto) + "\n";

    let agregado = agregarTexto(texto, extra);
    res += "Añadido al inicio: " + agregado.inicio + "\n";
    res += "Añadido al final: " + agregado.fin + "\n";

    document.getElementById("resultado").textContent = res;
}
