class AnalizadorTexto {

    constructor(texto) {
        this.texto = texto;
    }

    // 1. Contar palabras
    contarPalabras() {
        let texto = this.texto;
        let palabras = 0;
        let dentro = false;

        for (let i = 0; i < texto.length; i++) {
            let c = texto[i];

            if (c !== " " && c !== "\n" && c !== "\t" && !dentro) {
                dentro = true;
                palabras++;
            }

            if (c === " " || c === "\n" || c === "\t") {
                dentro = false;
            }
        }
        return palabras;
    }

    // 2. Contar signos de puntuación
    contarSignos() {
        let texto = this.texto;
        let signos = ".,;:!?¿¡\"";
        let cont = 0;

        for (let i = 0; i < texto.length; i++) {
            for (let j = 0; j < signos.length; j++) {
                if (texto[i] === signos[j]) cont++;
            }
        }
        return cont;
    }

    // 3. Contar vocales
    contarVocales() {
        let texto = this.texto;
        let vocales = "aeiouAEIOU";
        let cont = 0;

        for (let i = 0; i < texto.length; i++) {
            for (let j = 0; j < vocales.length; j++) {
                if (texto[i] === vocales[j]) cont++;
            }
        }
        return cont;
    }

    // 4. Contar consonantes
    contarConsonantes() {
        let texto = this.texto;
        let vocales = "aeiouAEIOU";
        let abc = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let cont = 0;

        for (let i = 0; i < texto.length; i++) {
            let c = texto[i];

            // es letra
            let esLetra = false;
            for (let j = 0; j < abc.length; j++) {
                if (c === abc[j]) esLetra = true;
            }
            if (!esLetra) continue;

            // vocal o no?
            let esVocal = false;
            for (let j = 0; j < vocales.length; j++) {
                if (c === vocales[j]) esVocal = true;
            }

            if (!esVocal) cont++;
        }
        return cont;
    }

    // 5. Contar dígitos
    contarDigitos() {
        let texto = this.texto;
        let digitos = "0123456789";
        let cont = 0;

        for (let i = 0; i < texto.length; i++) {
            for (let j = 0; j < digitos.length; j++) {
                if (texto[i] === digitos[j]) cont++;
            }
        }
        return cont;
    }

    // 6. Palabras con mayúscula inicial (corregido)
    palabrasMayuscula() {
        let texto = this.texto;
        let mayus = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        let separadores = " \n.,;:!?¿¡\"";
        let cont = 0;
        let iniciar = true;

        for (let i = 0; i < texto.length; i++) {
            let c = texto[i];

            // Detectar si es separador
            let esSeparador = false;
            for (let j = 0; j < separadores.length; j++) {
                if (c === separadores[j]) esSeparador = true;
            }

            if (!esSeparador) {
                if (iniciar) {
                    // Ver si está en mayúsculas
                    for (let j = 0; j < mayus.length; j++) {
                        if (c === mayus[j]) cont++;
                    }
                    iniciar = false;
                }
            } else {
                iniciar = true;
            }
        }

        return cont;
    }

    // 7. Palabras con minúscula inicial (corregido)
    palabrasMinuscula() {
        let texto = this.texto;
        let minus = "abcdefghijklmnopqrstuvwxyz";
        let separadores = " \n.,;:!?¿¡\"";
        let cont = 0;
        let iniciar = true;

        for (let i = 0; i < texto.length; i++) {
            let c = texto[i];

            // Detectar separador
            let esSeparador = false;
            for (let j = 0; j < separadores.length; j++) {
                if (c === separadores[j]) esSeparador = true;
            }

            if (!esSeparador) {
                if (iniciar) {
                    for (let j = 0; j < minus.length; j++) {
                        if (c === minus[j]) cont++;
                    }
                    iniciar = false;
                }
            } else {
                iniciar = true;
            }
        }

        return cont;
    }

    // 8. Contar párrafos
    contarParrafos() {
        let texto = this.texto;

        if (texto.length === 0) return 0;

        let cont = 1;
        for (let i = 0; i < texto.length; i++) {
            if (texto[i] === "\n") cont++;
        }
        return cont;
    }

    // 9. Invertir texto
    invertirTexto() {
        let texto = this.texto;
        let invertido = "";

        for (let i = texto.length - 1; i >= 0; i--) {
            invertido += texto[i];
        }
        return invertido;
    }

    // 10. Total de caracteres
    contarCaracteres() {
        return this.texto.length;
    }

    // 11. Buscar palabra
    buscarPalabra(palabra) {
        let texto = this.texto;

        for (let i = 0; i < texto.length; i++) {
            let igual = true;

            for (let j = 0; j < palabra.length; j++) {
                if (texto[i + j] !== palabra[j]) {
                    igual = false;
                    break;
                }
            }

            if (igual) return true;
        }
        return false;
    }

    // 12. Contar carácter
    contarCaracter(c) {
        let texto = this.texto;
        let cont = 0;

        for (let i = 0; i < texto.length; i++) {
            if (texto[i] === c) cont++;
        }
        return cont;
    }

    // 13. Caracteres pares
    caracteresPares() {
        let cont = 0;
        for (let i = 0; i < this.texto.length; i += 2) cont++;
        return cont;
    }

    // 14. Caracteres impares
    caracteresImpares() {
        let cont = 0;
        for (let i = 1; i < this.texto.length; i += 2) cont++;
        return cont;
    }

    // 15. Añadir texto
    agregarTexto(extra) {
        return {
            inicio: extra + " " + this.texto,
            fin: this.texto + " " + extra
        };
    }
}


// =========================
// FUNCIÓN PRINCIPAL
// =========================
function analizarTexto() {
    let texto = document.getElementById("texto").value;
    let analizador = new AnalizadorTexto(texto);

    let res = "";

    res += "Palabras: " + analizador.contarPalabras() + "\n";
    res += "Signos de puntuación: " + analizador.contarSignos() + "\n";
    res += "Vocales: " + analizador.contarVocales() + "\n";
    res += "Consonantes: " + analizador.contarConsonantes() + "\n";
    res += "Dígitos: " + analizador.contarDigitos() + "\n";

    res += "Palabras con mayúscula inicial: " + analizador.palabrasMayuscula() + "\n";
    res += "Palabras con minúscula inicial: " + analizador.palabrasMinuscula() + "\n";

    res += "Párrafos: " + analizador.contarParrafos() + "\n";
    res += "Texto invertido: \"" + analizador.invertirTexto() + "\"\n";
    res += "Total de caracteres: " + analizador.contarCaracteres() + "\n";

    document.getElementById("resultado").textContent = res;
}
